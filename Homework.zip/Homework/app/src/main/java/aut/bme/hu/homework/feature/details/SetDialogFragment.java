package aut.bme.hu.homework.feature.details;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import aut.bme.hu.homework.R;

public class SetDialogFragment extends DialogFragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.dialog_fragment, container, false);
//
//        TextView tvId = rootView.findViewById(R.id.tvId);
//        TextView tvSSN = rootView.findViewById(R.id.tvSSN);
//        TextView tvTaxId = rootView.findViewById(R.id.tvTaxId);
//        TextView tvRegistrationId = rootView.findViewById(R.id.tvRegistrationId);
//
//
//        tvId.setText(person.getId());
//        tvSSN.setText(person.getSocialSecurityNumber());
//        tvTaxId.setText(person.getTaxId());
//        tvRegistrationId.setText(person.getRegistrationId());

        return rootView;
    }

    @Override
    public void onCancel(DialogInterface dialog) {

    }

    @Override
    public void onDismiss(DialogInterface dialog) {

    }
}
