package aut.bme.hu.homework.feature.transaction;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import aut.bme.hu.homework.R;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.CityViewHolder> {

    private final List<Transaction> transactions;

    private OnCitySelectedListener listener;

    public interface OnCitySelectedListener {
        void onCitySelected(Transaction transaction);
    }

    TransactionAdapter(OnCitySelectedListener listener) {
        this.listener = listener;
        transactions = new ArrayList<>();
    }

    @NonNull
    @Override
    public CityViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new CityViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull CityViewHolder holder, int position) { //ITT ADOM BELE HOGY MIT ÍRJON KI
        Transaction item = transactions.get(position);

        String a = String.format("%s %tB %<te, %<tY", "", transactions.get(position).getDate());

        int value = transactions.get(position).getValue();
        if(value < 0)
            holder.valueTextView.setTextColor(Color.RED);
        else
            holder.valueTextView.setTextColor(Color.GREEN);
        holder.valueTextView.setText(Integer.toString(value));


        holder.whenTextView.setText(a);
        holder.fromTextView.setText(transactions.get(position).getFrom());
        holder.idTextView.setText(Integer.toString(transactions.get(position).getId()));

        holder.item = item;

    }

    public Transaction getTransaction(int a){
        return transactions.get(a);
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }


    public void addTransaction(Transaction t) {
        transactions.add(t);
        notifyItemInserted(transactions.size() - 1);
    }

    public void removeCity(int position) {
        transactions.remove(position);
        notifyItemRemoved(position);
        if (position < transactions.size()) {
            notifyItemRangeChanged(position, transactions.size() - position);
        }
    }

    class CityViewHolder extends RecyclerView.ViewHolder {

        TextView valueTextView;
        TextView idTextView;
        TextView whenTextView;
        TextView fromTextView;
       // Button removeButton;

        Transaction item;

        CityViewHolder(View itemView) {
            super(itemView);

            valueTextView = itemView.findViewById(R.id.TransactionValueTextView);
            idTextView = itemView.findViewById(R.id.TransactionIDTextView);
            whenTextView = itemView.findViewById(R.id.TransactionWhenTextView);
            fromTextView = itemView.findViewById(R.id.TransactionFromTextView);
           // removeButton = itemView.findViewById(R.id.CityItemRemoveButton);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        listener.onCitySelected(item);
                    }
                }
            });

        }
    }
}
