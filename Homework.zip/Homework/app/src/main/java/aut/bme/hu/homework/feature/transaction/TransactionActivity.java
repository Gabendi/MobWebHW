package aut.bme.hu.homework.feature.transaction;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

import java.util.Date;

import aut.bme.hu.homework.R;
import aut.bme.hu.homework.feature.details.DetailsActivity;

public class TransactionActivity extends AppCompatActivity
        implements TransactionAdapter.OnCitySelectedListener{

    private RecyclerView recyclerView;
    private TransactionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);


        Log.d("asd","isToolbarWorking");
        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        initRecyclerView();
    }

    public Transaction getTransaction(int a){
        return adapter.getTransaction(a);
    }


    private void initRecyclerView() {
        recyclerView = findViewById(R.id.MainRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TransactionAdapter(this);
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"BMEBEMEMEME",44)); // adding the examples
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",-44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",-44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",-44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));
        adapter.addTransaction(new Transaction(33,new Date(109,01,22),"c",44));



        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onCitySelected(Transaction transaction) {
        // Todo: Start DetailsActivity with the selected city
        Intent showDetailsIntent = new Intent();
        showDetailsIntent.setClass(TransactionActivity.this, DetailsActivity.class);
        showDetailsIntent.putExtra("Transaction",transaction);
        startActivity(showDetailsIntent);
    }

    public void onCityAdded(Transaction t) {
        adapter.addTransaction(t);
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        Log.d("asd","oncreateoptionsmenu");
        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        final Menu toolbarMenu = toolbar.getMenu();
        getMenuInflater().inflate(R.menu.menu_toolbar, toolbarMenu);


        for (int i = 0; i < toolbarMenu.size(); i++) {
            final MenuItem menuItem = toolbarMenu.getItem(i);
            menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(final MenuItem item) {
                    return onOptionsItemSelected(item);
                }
            });
            if (menuItem.hasSubMenu()) {
                final SubMenu subMenu = menuItem.getSubMenu();
                for (int j = 0; j < subMenu.size(); j++) {
                    subMenu.getItem(j).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(final MenuItem item) {
                            return onOptionsItemSelected(item);
                        }
                    });
                }
            }
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_style_line:
                item.setChecked(true);
                return true;
            case R.id.menu_style_point:
                item.setChecked(true);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
