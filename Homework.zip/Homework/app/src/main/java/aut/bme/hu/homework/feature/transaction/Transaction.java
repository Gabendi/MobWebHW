package aut.bme.hu.homework.feature.transaction;

import java.io.Serializable;
import java.util.Date;

public class Transaction  implements Serializable {
    private int id;
    private Date date;
    private String from;
    private int value;

    public Transaction(int id, Date date, String from, int value) {
        this.id = id;
        this.date = date;
        this.from = from;
        this.value = value;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }





}
