package aut.bme.hu.homework.feature.details;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import aut.bme.hu.homework.R;
import aut.bme.hu.homework.feature.transaction.Transaction;

public class DetailsActivity extends AppCompatActivity {

    private static final String TAG = "DetailsActivity";


    private Transaction transaction;

    private TextView tvfrom;
    private TextView tvwhen;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        transaction =(Transaction)getIntent().getSerializableExtra("Transaction");

        tvfrom = findViewById(R.id.DetailedTransactionFromTextView);
        tvwhen = findViewById(R.id.DetailedTransactionValueTextView);
        button = findViewById(R.id.Detailedbtn);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new SetDialogFragment().show(getSupportFragmentManager(),"ASD");
            }
        });
        tvfrom.setText(transaction.getFrom().toString());
        tvwhen.setText(transaction.getDate().toString());
        getSupportActionBar().setTitle(transaction.getFrom()); //el kell kérni vmit!

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
